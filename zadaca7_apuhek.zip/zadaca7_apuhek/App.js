import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
} from 'react-native';
import Constants from 'expo-constants';
import Ionicons from '@expo/vector-icons/Ionicons';
import { AntDesign } from '@expo/vector-icons';

export default function App() {
  return (
    <>
      <View style={styles.container}>
        <View style={styles.subContainer}>
          <Text style={styles.screenTitle}>Sign in</Text>
          <Text style={styles.screenSubTitle}>
            Stay updated on your professional world
          </Text>
          <TextInput style={styles.input} placeholder="Email or Phone" />
          <View style={styles.passInput}>
            <TextInput
              style={styles.pass1Input}
              secureTextEntry={true}
              placeholder="Password"
            />
            <TouchableOpacity style={styles.showHideBtn}>
              <Text style={styles.showHideBtnTxt}>show</Text>
            </TouchableOpacity>
          </View>
          <TouchableOpacity>
            <Text style={styles.forgot}>Forgot password?</Text>
          </TouchableOpacity>
          <View style={styles.btnSection}>
            <TouchableOpacity style={styles.singinBtn}>
              <Text style={styles.singinBtnTxt}>Sign in</Text>
            </TouchableOpacity>

            <View style={styles.divider}>
              <View style={styles.dividerLine}></View>
              <Text style={styles.dividerTxt}>or</Text>
              <View style={styles.dividerLine}></View>
            </View>

            <TouchableOpacity style={styles.singinBtnApple}>
              <AntDesign name="apple1" size={24} color="black" />
              <Text style={styles.singinBtnTxtApple}>Sign in width apple</Text>
            </TouchableOpacity>
          </View>
        </View>
        <View style={styles.dontHave}>
          <Text style={styles.dontHaveTxt}>New to LinkedIn?</Text>
          <Text style={styles.dontHaveTxtBlue}>Join now</Text>
        </View>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ffffff',
    padding: 15,
  },
  subContainer: {
    marginTop: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.27,
    shadowRadius: 10.65,
    elevation: 6,
    padding: 10,
  },
  screenTitle: {
    fontSize: 30,
    fontWeight: 700,
  },
  screenSubTitle: {
    marginTop: 10,
    fontSize: 15,
    fontWeight: 500,
    color: '#616161',
  },
  input: {
    marginTop: 35,
    height: 40,
    borderWidth: 2,
    padding: 10,
    outline: 0,
    borderRadius: 5,
    color: '#616161',
    fontSize: 18,
    borderColor: '#969696',
  },
  passInput: {
    marginTop: 15,
    flexDirection: 'row',
    alignItems: 'center',
    height: 40,
    borderWidth: 2,
    padding: 10,
    borderRadius: 5,
    // color: '#616161',
    borderColor: '#969696',
  },
  pass1Input: {
    fontSize: 18,
    outline: 0,
    color: '#616161',
  },

  showHideBtn: {
    marginLeft: 'auto',
  },
  showHideBtnTxt: {
    color: '#2d64bc',
    fontWeight: 700,
  },

  forgot: {
    marginTop: 15,
    color: '#2d64bc',
    fontWeight: 500,
  },
  singinBtn: {
    marginTop: 105,
    backgroundColor: '#2d64bc',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 15,
    borderRadius: 35,
    border: 'none',
  },
  singinBtnTxt: {
    fontWeight: 700,
    color: '#f9fbfd',
  },
  singinBtnApple: {
    marginTop: 15,
    backgroundColor: 'transparent',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 15,
    borderRadius: 35,
    border: '1px solid #616161',
    flexDirection: 'row',
  },
  singinBtnTxtApple: {
    fontWeight: 700,
    color: '#616161',
    marginLeft: 10,
  },
  divider: {
    marginTop: 10,
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    flexDirection: 'row',
  },
  dividerLine: {
    border: '1px solid #dddddd',
    width: '46%',
    marginTop: 5,
    backgroundColor: '#dddddd',
  },
  dividerTxt: {
    marginLeft: 5,
    marginRight: 5,
    color: '#919191',
  },
  dontHave: {
    marginTop: 25,
    flex: 1,
    justifyContent: 'center',
    flexDirection: 'row',
  },
  dontHaveTxt: {
    color: '#111111',
    fontSize: 16,
    fontWeight: 500,
  },
  dontHaveTxtBlue: {
    marginLeft: 5,
    fontSize: 16,
    color: '#2d64bc',
    fontWeight: 500,
  },
});
